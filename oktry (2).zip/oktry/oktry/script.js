// JavaScript source code
window.onload = function () {
    var orderForm = document.forms.orderForm;
    orderForm.elements.name.value = "CSC371";
    //alert(orderForm.elements.name.value);
    orderForm.elements.address.focus();
}

function start() {
    var size = orderForm.elements.size;
    var sizeIndex = size.selectedIndex;
    var sizeValue = size.options[sizeIndex].value;
    alert(sizeValue);
    // Radio buttons
    var crust = document.querySelector('input[name = "crust"]:checked').value;
    alert(crust);

    // Check Box

    var toppings = orderForm.elements.toppings;
    //alert(toppings.length);
    for (var i = 0; i < toppings.length; i++) {
        if (toppings[i].checked === true) {
            var top = toppings[i].value;
            alert(top);
        }
    }
}

// work with numbers
var numbers = orderForm.elements.instructions.value;
var result = Number(number).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
alert(result);
